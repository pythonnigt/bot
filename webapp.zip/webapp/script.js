const pricesDiv = document.getElementById('prices');

async function loadPrices() {
    pricesDiv.innerHTML = "<p>Yuklanmoqda...</p>";
    
    try {
        // CoinGecko API (bepul)
        const response = await fetch(
            'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1'
        );
        const data = await response.json();

        let html = '<table><tr><th>#</th><th>Coin</th><th>Narx (USD)</th><th>24h</th></tr>';
        
        data.forEach(coin => {
            const change = coin.price_change_percentage_24h;
            const color = change >= 0 ? 'green' : 'red';
            
            html += `
                <tr>
                    <td>${coin.market_cap_rank}</td>
                    <td><img src="${coin.image}" width="24"> ${coin.symbol.toUpperCase()}</td>
                    <td>$${coin.current_price.toLocaleString()}</td>
                    <td style="color:${color}">${change.toFixed(2)}%</td>
                </tr>`;
        });
        
        html += '</table>';
        pricesDiv.innerHTML = html;
    } catch (e) {
        pricesDiv.innerHTML = "<p>Xatolik yuz berdi. Qayta urinib ko‘ring.</p>";
    }
}

// Sahifa ochilganda avtomatik yuklash
window.onload = loadPrices;